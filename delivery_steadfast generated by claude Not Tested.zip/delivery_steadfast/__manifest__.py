{
    'name': 'Steadfast Courier Delivery',
    'version': '18.0.1.0.0',
    'category': 'Inventory/Delivery',
    'summary': 'Delivery carrier integration with Steadfast Courier (Bangladesh)',
    'description': """
Steadfast Courier Integration
==============================
Integrates Steadfast Courier (portal.steadfast.com.bd) as a delivery
carrier in Odoo 18. Features:

- Create consignments directly from delivery orders
- Auto-fetch tracking codes from Steadfast API
- Track shipment status from the delivery order
- Check account balance
- COD (Cash on Delivery) support
    """,
    'author': 'Custom',
    'website': 'https://steadfast.com.bd',
    'depends': ['delivery', 'stock', 'sale'],
    'data': [
        'security/ir.model.access.csv',
        'data/delivery_steadfast_data.xml',
        'views/delivery_steadfast_view.xml',
    ],
    'images': ['static/description/icon.png'],
    'license': 'LGPL-3',
    'installable': True,
    'application': False,
    'auto_install': False,
}
