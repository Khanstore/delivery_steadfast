import logging
import requests

from odoo import _, api, fields, models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

STEADFAST_API_URL = 'https://portal.steadfast.com.bd/public/api/v1'

STEADFAST_STATUS_LABEL = {
    'pending':           ('Pending',            'info'),
    'in_review':         ('In Review',          'warning'),
    'cancelled':         ('Cancelled',          'danger'),
    'on_hold':           ('On Hold',            'warning'),
    'in_transit':        ('In Transit',         'primary'),
    'delivered':         ('Delivered',          'success'),
    'partial_delivered': ('Partial Delivered',  'success'),
    'returned':          ('Returned',           'danger'),
    'partial_returned':  ('Partial Returned',   'danger'),
    'payment_completed': ('Payment Completed',  'success'),
    'unknown':           ('Unknown',            'secondary'),
}


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    steadfast_tracking_code = fields.Char(
        string='Steadfast Tracking Code',
        copy=False,
        readonly=True,
    )
    steadfast_consignment_id = fields.Char(
        string='Steadfast Consignment ID',
        copy=False,
        readonly=True,
    )
    steadfast_status = fields.Selection(
        selection=[(k, v[0]) for k, v in STEADFAST_STATUS_LABEL.items()],
        string='Steadfast Status',
        copy=False,
        readonly=True,
    )
    steadfast_status_badge = fields.Char(
        string='Status Badge',
        compute='_compute_steadfast_status_badge',
    )

    @api.depends('steadfast_status')
    def _compute_steadfast_status_badge(self):
        for rec in self:
            status = rec.steadfast_status or 'unknown'
            rec.steadfast_status_badge = STEADFAST_STATUS_LABEL.get(status, ('Unknown', 'secondary'))[1]

    # ------------------------------------------------------------------
    # Track shipment
    # ------------------------------------------------------------------

    def action_steadfast_update_status(self):
        """Fetch latest status from Steadfast and update the picking."""
        for picking in self:
            if not picking.steadfast_tracking_code:
                raise UserError(_(
                    'No Steadfast tracking code on "%s". '
                    'Please send the shipment first.'
                ) % picking.name)

            carrier = picking.carrier_id
            if not carrier or carrier.delivery_type != 'steadfast':
                raise UserError(_('Carrier on "%s" is not Steadfast.') % picking.name)

            headers = carrier._steadfast_headers()
            url = (
                f'{STEADFAST_API_URL}/status_by_trackingcode'
                f'/{picking.steadfast_tracking_code}'
            )
            try:
                response = requests.get(url, headers=headers, timeout=30)
                response.raise_for_status()
                data = response.json()
            except Exception as e:
                raise UserError(_('Failed to fetch Steadfast status: %s') % str(e))

            delivery_status = data.get('delivery_status')
            if delivery_status is None:
                raise UserError(
                    _('Unexpected Steadfast response:\n%s') % str(data)
                )

            # Map integer status code → our selection key
            status_map = {
                1:  'pending',
                2:  'in_review',
                3:  'cancelled',
                4:  'on_hold',
                5:  'in_transit',
                6:  'delivered',
                7:  'partial_delivered',
                8:  'returned',
                9:  'partial_returned',
                10: 'payment_completed',
                11: 'unknown',
            }
            status_key = status_map.get(delivery_status, 'unknown')
            picking.steadfast_status = status_key

            label = STEADFAST_STATUS_LABEL.get(status_key, ('Unknown', 'secondary'))[0]
            _logger.info(
                'Steadfast status updated — picking: %s, status: %s',
                picking.name, label,
            )

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Steadfast Status Updated'),
                'message': _('Status: %s') % label,
                'type': 'success',
                'sticky': False,
            },
        }

    def action_steadfast_open_tracking(self):
        """Open the Steadfast public tracking page."""
        self.ensure_one()
        if not self.steadfast_tracking_code:
            raise UserError(_('No tracking code available yet.'))
        return {
            'type': 'ir.actions.act_url',
            'url': f'https://steadfast.com.bd/t/{self.steadfast_tracking_code}',
            'target': 'new',
        }
