import json
import logging
import requests

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)

STEADFAST_API_URL = 'https://portal.steadfast.com.bd/public/api/v1'

STEADFAST_STATUS_MAP = {
    1:  'pending',
    2:  'in_review',
    3:  'cancelled',
    4:  'on_hold',
    5:  'in_transit',
    6:  'delivered',
    7:  'partial_delivered',
    8:  'returned',
    9:  'partial_returned',
    10: 'payment_completed',
    11: 'unknown',
}


class ProviderSteadfast(models.Model):
    _inherit = 'delivery.carrier'

    delivery_type = fields.Selection(
        selection_add=[('steadfast', 'Steadfast Courier')],
        ondelete={'steadfast': 'set default'},
    )

    steadfast_api_key = fields.Char(
        string='API Key',
        groups='base.group_system',
        help='Your Steadfast API Key from portal.steadfast.com.bd',
    )
    steadfast_secret_key = fields.Char(
        string='Secret Key',
        groups='base.group_system',
        help='Your Steadfast Secret Key from portal.steadfast.com.bd',
    )
    steadfast_default_cod = fields.Float(
        string='Default COD Amount',
        default=0.0,
        help='Default Cash on Delivery amount if not taken from sale order.',
    )
    steadfast_cod_from_order = fields.Boolean(
        string='COD from Sale Order',
        default=True,
        help='Automatically use the sale order total as the COD amount.',
    )
    steadfast_note = fields.Char(
        string='Default Note',
        help='Optional note/instruction sent with every consignment.',
    )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _steadfast_headers(self):
        self.ensure_one()
        if not self.steadfast_api_key or not self.steadfast_secret_key:
            raise UserError(_(
                'Please configure the Steadfast API Key and Secret Key '
                'on the delivery carrier "%s".'
            ) % self.name)
        return {
            'Api-Key': self.steadfast_api_key,
            'Secret-Key': self.steadfast_secret_key,
            'Content-Type': 'application/json',
        }

    def _steadfast_request(self, method, endpoint, payload=None):
        """Low-level HTTP wrapper for the Steadfast API."""
        self.ensure_one()
        url = f'{STEADFAST_API_URL}/{endpoint.lstrip("/")}'
        headers = self._steadfast_headers()
        try:
            response = requests.request(
                method,
                url,
                headers=headers,
                json=payload,
                timeout=30,
            )
            response.raise_for_status()
        except requests.exceptions.Timeout:
            raise UserError(_('Steadfast API request timed out. Please try again.'))
        except requests.exceptions.ConnectionError:
            raise UserError(_('Could not connect to Steadfast API. Check your internet connection.'))
        except requests.exceptions.HTTPError as e:
            raise UserError(_('Steadfast API error: %s') % str(e))

        try:
            data = response.json()
        except ValueError:
            raise UserError(_('Steadfast returned an invalid response.'))

        # Steadfast wraps errors in status != 200
        if data.get('status') not in (200, 201):
            raise UserError(
                _('Steadfast API returned an error:\n%s') % data.get('message', str(data))
            )
        return data

    def _steadfast_cod_amount(self, picking):
        """Resolve the COD amount for a picking."""
        self.ensure_one()
        if self.steadfast_cod_from_order and picking.sale_id:
            return picking.sale_id.amount_total
        return self.steadfast_default_cod

    def _steadfast_recipient(self, picking):
        """Build recipient info from the picking's delivery address."""
        partner = picking.partner_id
        if not partner:
            raise UserError(_('No delivery address set on the transfer "%s".') % picking.name)

        phone = partner.mobile or partner.phone
        if not phone:
            raise UserError(_(
                'Partner "%s" has no phone/mobile number. '
                'Steadfast requires a recipient phone number.'
            ) % partner.name)

        address_parts = filter(None, [
            partner.street,
            partner.street2,
            partner.city,
            partner.state_id.name if partner.state_id else None,
            partner.country_id.name if partner.country_id else None,
        ])
        address = ', '.join(address_parts) or partner.contact_address

        return {
            'recipient_name': partner.name,
            'recipient_phone': phone,
            'recipient_address': address,
        }

    # ------------------------------------------------------------------
    # Delivery carrier API — rate
    # ------------------------------------------------------------------

    def steadfast_rate_shipment(self, order):
        """Steadfast does not provide a public rate API; return a fixed price."""
        return {
            'success': True,
            'price': self.product_id.lst_price if self.product_id else 0.0,
            'error_message': False,
            'warning_message': _(
                'Steadfast does not provide live rates. '
                'The price shown is the carrier product price.'
            ),
        }

    # ------------------------------------------------------------------
    # Delivery carrier API — send
    # ------------------------------------------------------------------

    def steadfast_send_shipping(self, pickings):
        """Create consignments on Steadfast for the given pickings."""
        results = []
        for picking in pickings:
            result = self._steadfast_create_consignment(picking)
            results.append(result)
        return results

    def _steadfast_create_consignment(self, picking):
        """POST /create_order for a single picking."""
        self.ensure_one()
        recipient = self._steadfast_recipient(picking)
        cod_amount = self._steadfast_cod_amount(picking)

        payload = {
            'invoice': picking.name,
            'cod_amount': cod_amount,
            'note': self.steadfast_note or '',
            **recipient,
        }

        _logger.info('Steadfast create_order payload: %s', payload)
        data = self._steadfast_request('POST', 'create_order', payload)

        consignment = data.get('consignment', {})
        tracking_code = consignment.get('tracking_code', '')
        consignment_id = consignment.get('id', '')

        if not tracking_code:
            raise UserError(_(
                'Steadfast did not return a tracking code for "%s". '
                'Response: %s'
            ) % (picking.name, data))

        # Store on picking
        picking.write({
            'steadfast_tracking_code': tracking_code,
            'steadfast_consignment_id': str(consignment_id),
            'steadfast_status': 'pending',
        })

        _logger.info(
            'Steadfast consignment created — picking: %s, tracking: %s',
            picking.name, tracking_code,
        )

        return {
            'exact_price': cod_amount,
            'tracking_number': tracking_code,
        }

    # ------------------------------------------------------------------
    # Delivery carrier API — tracking
    # ------------------------------------------------------------------

    def steadfast_get_tracking_link(self, picking):
        """Return a public tracking URL."""
        tracking = picking.steadfast_tracking_code
        if tracking:
            return f'https://steadfast.com.bd/t/{tracking}'
        return False

    def steadfast_cancel_shipment(self, pickings):
        """Steadfast does not support cancellation via API; notify user."""
        raise UserError(_(
            'Steadfast does not support shipment cancellation via API. '
            'Please cancel manually at portal.steadfast.com.bd.'
        ))

    # ------------------------------------------------------------------
    # Extra: check balance
    # ------------------------------------------------------------------

    def action_steadfast_check_balance(self):
        self.ensure_one()
        data = self._steadfast_request('GET', 'get_balance')
        balance = data.get('current_balance', 'N/A')
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Steadfast Account Balance'),
                'message': _('Current balance: ৳ %s') % balance,
                'type': 'success',
                'sticky': False,
            },
        }

    # ------------------------------------------------------------------
    # Extra: bulk create consignments wizard shortcut
    # ------------------------------------------------------------------

    def action_steadfast_test_connection(self):
        self.ensure_one()
        try:
            data = self._steadfast_request('GET', 'get_balance')
            balance = data.get('current_balance', 'N/A')
            msg = _('✅ Connection successful! Balance: ৳ %s') % balance
            msg_type = 'success'
        except UserError as e:
            msg = str(e)
            msg_type = 'danger'
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Steadfast Connection Test'),
                'message': msg,
                'type': msg_type,
                'sticky': True,
            },
        }
